def how(string):
    return len(set(string.lower()))


print(how('Hello, World!'))

# 10
# Какие учебники по теории множеств вы можете посоветовать?
